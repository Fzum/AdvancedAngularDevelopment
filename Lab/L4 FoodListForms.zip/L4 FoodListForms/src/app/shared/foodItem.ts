export class FoodItem {
  id: number;
  name: string;
  price: number;
  calories: number;
}
