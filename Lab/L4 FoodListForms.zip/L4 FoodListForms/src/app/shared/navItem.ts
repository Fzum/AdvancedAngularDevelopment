export class NavItem {
  title: string;
  url: string;
}
